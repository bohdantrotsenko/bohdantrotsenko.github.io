﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

class SingleThreadTest : ITest
{
    public void Test()
    {
        //Console.WriteLine("SingleThreadTest()");

        var sw = Stopwatch.StartNew();
        for (int i = 0; i < Program.IterationCount; ++i)
        {
            var tmp = Primes.NextPrime(Program.SelectedPrimeCandidate);
        }
        sw.Stop();

        var ms = sw.Elapsed.TotalMilliseconds;
        var perf = Program.IterationCount / ms;
        Console.WriteLine("{0},{1},{2},{3},{4},{5},{6}",
            Environment.MachineName,
            Environment.OSVersion,
            "Direct",
            Program.SelectedPrimeCandidate,
            0,
            ms,
            perf);
        //Console.WriteLine("Did {0} iterations in {1} ms, that's {2} iterations / ms ", Program.IterationCount, ms, perf);
    }

    public void Dispose() { }
}


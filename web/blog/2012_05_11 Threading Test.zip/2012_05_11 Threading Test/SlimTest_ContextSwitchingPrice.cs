﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading;

class MessageSlim : IDisposable
{
    internal IManualResetEvent _MessageReady = Factory.GetEvent();

    public void Dispose()
    {
        if (_MessageReady != null)
        {
            _MessageReady.Dispose();
            _MessageReady = null;
        }
    }
}

class ExitMessageSlim : MessageSlim
{
    public void DeclareProcessed()
    {
        _MessageReady.Set();
    }
}

abstract class FuncMessageSlim : MessageSlim
{
    public abstract void Compute();
}

class FuncMessageSlim<I, T> : FuncMessageSlim
{
    internal Func<I, T> _Function;
    internal I _Argument;
    internal T _Result;

    public FuncMessageSlim(Func<I, T> function, I arg)
    {
        _Function = function;
        _Argument = arg;
    }

    public override void Compute()
    {
        _Result = _Function(_Argument);
        _MessageReady.Set();
    }

    public T AwaitResult()
    {
        _MessageReady.Wait();
        return _Result;
    }
}

class MultiThreadedTest : ThreadedTest
{
    ISemaphore[] _sems;
    Queue<MessageSlim>[] _queues;

    protected void PostMessage(int queueIdx, MessageSlim msg)
    {
        var q = _queues[queueIdx];
        lock (q)
            q.Enqueue(msg);
        _sems[queueIdx].Release();
    }

    public MultiThreadedTest(int threadsCount) : base(threadsCount)
    {
        _sems = new ISemaphore[_ThreadsCount];
        _queues = new Queue<MessageSlim>[_ThreadsCount];
        for (int i = 0; i < _ThreadsCount; ++i)
        {
            _sems[i] = Factory.GetSemaphore();
            _queues[i] = new Queue<MessageSlim>();
        }
    }

    protected override void SignalThreadsExit()
    {
        for (int i = 0; i < _ThreadsCount; ++i)
            PostMessage(i, new ExitMessageSlim());
    }

    protected override ThreadStart GetOrCreateWorker(int index)
    {
        return () => Worker(index);
    }

    void Worker(int index)
    {
        var q = _queues[index];
        while (true)
        {
            // wait for message
            _sems[index].Wait();

            // get the message
            MessageSlim msg;
            lock (q)
                msg = q.Dequeue();

            // process message
            if (msg is FuncMessageSlim)
            {
                var m = (FuncMessageSlim)msg;
                m.Compute();
            }
            else if (msg is ExitMessageSlim)
            {
                var m = (ExitMessageSlim)msg;
                m.DeclareProcessed();
                break;
            }
            else
                throw new NotImplementedException();
        }
    }

    public override void Test()
    {
        //Console.WriteLine("ThreadsCount = {0}", _ThreadsCount );
        StartWorkers();

        // do some dummy work; just to ensure threads are started and ready to work
        for (int i = 0; i < _ThreadsCount; ++i)
        {
            var msg = new FuncMessageSlim<int, int>(p => 1, 1);
            PostMessage(i, msg);
            msg.AwaitResult();
            msg.Dispose();
        }

        var sw = Stopwatch.StartNew();

        int threadIdx = 0;
        for (int i = 0; i < Program.IterationCount; ++i)
        {
            var msg = new FuncMessageSlim<int, int>(p => Primes.NextPrime(p), Program.SelectedPrimeCandidate);
            PostMessage(threadIdx, msg);
            msg.AwaitResult();
            msg.Dispose();

            threadIdx = (threadIdx + 1) % _ThreadsCount;
        }

        sw.Stop();

        var ms = sw.Elapsed.TotalMilliseconds;
        var perf = Program.IterationCount / ms;
        Console.WriteLine("{0},{1},{2},{3},{4},{5},{6}",
            Environment.MachineName,
            Environment.OSVersion,
            Factory.Typename,
            Program.SelectedPrimeCandidate,
            _ThreadsCount,
            ms,
            perf);
        //Console.WriteLine("Did {0} iterations in {1} ms, that's {2} iterations / ms ", Program.IterationCount, ms, perf);
    }

    public override void Dispose()
    {
        base.Dispose();
        if (_sems != null)
        {
            for (int i = 0; i < _ThreadsCount; ++i)
                _sems[i].Dispose();
            _sems = null;
        }
    }
}

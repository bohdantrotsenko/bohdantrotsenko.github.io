﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

class Factory
{
    public static string Typename;

    public static Func<IManualResetEvent> GetEvent;

    public static Func<ISemaphore> GetSemaphore;
}

interface IManualResetEvent : IDisposable
{
    void Wait();
    void Set();
    void Reset();
}

class SlimEvent : IManualResetEvent
{
    ManualResetEventSlim e = new ManualResetEventSlim(false);

    public void Wait()
    {
        e.Wait();
    }

    public void Set()
    {
        e.Set();
    }

    public void Reset()
    {
        e.Reset();
    }

    public void Dispose()
    {
        e.Dispose();
    }
}

class TradEvent : IManualResetEvent
{
    EventWaitHandle e = new EventWaitHandle(false, EventResetMode.ManualReset);

    public void Wait()
    {
        e.WaitOne();
    }

    public void Set()
    {
        e.Set();
    }

    public void Reset()
    {
        e.Reset();
    }

    public void Dispose()
    {
        e.Dispose();
    }
}

interface ISemaphore : IDisposable
{
    void Wait();
    void Release();
}

class SlimSem : ISemaphore
{
    SemaphoreSlim s = new SemaphoreSlim(0);

    public void Wait()
    {
        s.Wait();
    }

    public void Release()
    {
        s.Release();
    }

    public void Dispose()
    {
        s.Dispose();
    }
}

class TradSem : ISemaphore
{
    Semaphore s = new Semaphore(0, int.MaxValue);

    public void Wait()
    {
        s.WaitOne();
    }

    public void Release()
    {
        s.Release();
    }

    public void Dispose()
    {
        s.Dispose();
    }
}
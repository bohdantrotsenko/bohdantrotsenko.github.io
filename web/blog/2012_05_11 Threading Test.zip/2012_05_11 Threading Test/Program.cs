﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading;
using System.Runtime.CompilerServices;

static class Util
{
    public static void PrintListLastItems<T>(IList<T> list, int maxCount = -1)
    {
        var n = list.Count;
        var s = new StringBuilder();
        int startIdx = maxCount >= 0 ? (maxCount > n ? 0 : n - maxCount) : 0;
        for (int i = startIdx; i < n; ++i)
        {
            if (i != startIdx) s.Append(' ');
            s.Append(list[i]);
        }

        Console.WriteLine("{0}", s.ToString());
    }
}

static class Primes
{
    public static bool IsPrime(int x)
    {
        int last = (int)Math.Sqrt(x);
        for (int lastDivisor = 2; lastDivisor <= last; ++lastDivisor)
            if (x % lastDivisor == 0)
                return false;
        return true;
    }

    public static int NextPrime(int x)
    {
        int candidate = x + 1;
        while (!IsPrime(candidate))
            ++candidate;
        return candidate;
    }
}

interface ITest : IDisposable
{
    void Test();
}

abstract class ThreadedTest : ITest
{
    public int _ThreadsCount;
    public readonly ThreadPriority WorkerThreadPriority = ThreadPriority.Lowest;
    
    protected Thread[] _Threads;
    protected volatile bool _ThreadsStarted = false;

    public ThreadedTest(int threadsCount)
    {
        _ThreadsCount = threadsCount;
        _Threads = new Thread[_ThreadsCount];
        for (int i = 0; i < _ThreadsCount; ++i)
            _Threads[i] = new Thread(GetOrCreateWorker(i));
    }

    public virtual void StartWorkers()
    {
        if (_ThreadsStarted)
            return;
        for (int i = 0; i < _ThreadsCount; ++i)
            _Threads[i].Start();
        _ThreadsStarted = true;
    }

    public virtual void Dispose()
    {
        SignalThreadsExit();
        for (int i = 0; i < _ThreadsCount; ++i)
            if (_Threads[i] != null)
            {
                _Threads[i].Join();
                _Threads[i] = null;
            }
    }

    protected abstract void SignalThreadsExit();
    protected abstract ThreadStart GetOrCreateWorker(int index);

    public abstract void Test();
}

class Program
{
    //public const int TargetPrimeBoundary = 100000;
    public const int IterationCount = 50000;
    public static volatile int SelectedPrimeCandidate
        = 2;
        // = 20000;

    static void Main(string[] args)
    {
        Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;

        var AmountOfWork = new int[] { 2, 200, 20000};
        foreach (var aow in AmountOfWork)
        {
            SelectedPrimeCandidate = aow;
            using (ITest test = new SingleThreadTest())
                test.Test();
            //Console.WriteLine("Now we'll search for the next prime after {0}", SelectedPrimeCandidate);
            for (int threadCount = 1; threadCount <= 16; ++threadCount)
            {
                //Console.WriteLine("Working with SlimEvent, SlimSemaphore");
                Factory.Typename = "Slim";
                Factory.GetEvent = () => new SlimEvent();
                Factory.GetSemaphore = () => new SlimSem();
                using (ITest test = new MultiThreadedTest(threadCount))
                    test.Test();
                //Console.WriteLine("Working with traditional Event, Semaphore");
                Factory.Typename = "Trad";
                Factory.GetEvent = () => new TradEvent();
                Factory.GetSemaphore = () => new TradSem();
                using (ITest test = new MultiThreadedTest(threadCount))
                    test.Test();
            }
        }
    }
}
